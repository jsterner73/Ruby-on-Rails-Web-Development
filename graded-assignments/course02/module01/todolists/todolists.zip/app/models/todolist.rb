class Todolist < ActiveRecord::Base
end
