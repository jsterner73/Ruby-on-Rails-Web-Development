class TodoItem < ActiveRecord::Base
end
